#!/bin/bash

##############################################################################################################
#                             Auto Install & Optimize LEMP Stack on Ubuntu                                   #
#                                                                                                            #
#                                    Author: Sanvv - MCN Technical                                        #
#                                        Website: https://mcnvps.net                                          #
#                                                                                                            #
#                                  Please do not remove copyright. Thank!                                    #
#  Copying or using this content for any commercial purpose is strictly prohibited under all circumstances!  #
##############################################################################################################

# shellcheck disable=SC2034

php_parameter(){
    if [[ "${CPU_CORES}" -ge '4' && "${CPU_CORES}" -lt '6' && "${RAM_TOTAL}" -gt '1049576' && "${RAM_TOTAL}" -le '2097152' ]]; then
        PM_MAX_CHILDREN=$((CPU_CORES * 6))
        PM_START_SERVERS=$((CPU_CORES * 4))
        PM_MIN_SPARE_SERVER=$((CPU_CORES * 2))
        PM_MAX_SPARE_SERVER=$((CPU_CORES * 6))
        PM_MAX_REQUEST=2000
    elif [[ "${CPU_CORES}" -ge '4' && "${CPU_CORES}" -lt '6' && "${RAM_TOTAL}" -gt '2097152' && "${RAM_TOTAL}" -le '3145728' ]]; then
        PM_MAX_CHILDREN=$((CPU_CORES * 6))
        PM_START_SERVERS=$((CPU_CORES * 4))
        PM_MIN_SPARE_SERVER=$((CPU_CORES * 2))
        PM_MAX_SPARE_SERVER=$((CPU_CORES * 6))
        PM_MAX_REQUEST=2000
    elif [[ "${CPU_CORES}" -ge '4' && "${CPU_CORES}" -lt '6' && "${RAM_TOTAL}" -gt '3145728' && "${RAM_TOTAL}" -le '4194304' ]]; then
        PM_MAX_CHILDREN=$((CPU_CORES * 6))
        PM_START_SERVERS=$((CPU_CORES * 4))
        PM_MIN_SPARE_SERVER=$((CPU_CORES * 2))
        PM_MAX_SPARE_SERVER=$((CPU_CORES * 6))
        PM_MAX_REQUEST=2000
    elif [[ "${CPU_CORES}" -ge '4' && "${CPU_CORES}" -lt '6' && "${RAM_TOTAL}" -gt '4194304' ]]; then
        PM_MAX_CHILDREN=$((CPU_CORES * 6))
        PM_START_SERVERS=$((CPU_CORES * 4))
        PM_MIN_SPARE_SERVER=$((CPU_CORES * 2))
        PM_MAX_SPARE_SERVER=$((CPU_CORES * 6))
        PM_MAX_REQUEST=2000
    elif [[ "${CPU_CORES}" -ge '6' && "${CPU_CORES}" -lt '8' && "${RAM_TOTAL}" -gt '3145728' && "${RAM_TOTAL}" -le '4194304' ]]; then
        PM_MAX_CHILDREN=$((CPU_CORES * 6))
        PM_START_SERVERS=$((CPU_CORES * 4))
        PM_MIN_SPARE_SERVER=$((CPU_CORES * 2))
        PM_MAX_SPARE_SERVER=$((CPU_CORES * 6))
        PM_MAX_REQUEST=2000
    elif [[ "${CPU_CORES}" -ge '6' && "${CPU_CORES}" -lt '8' && "${RAM_TOTAL}" -gt '4194304' ]]; then
        PM_MAX_CHILDREN=$((CPU_CORES * 6))
        PM_START_SERVERS=$((CPU_CORES * 4))
        PM_MIN_SPARE_SERVER=$((CPU_CORES * 2))
        PM_MAX_SPARE_SERVER=$((CPU_CORES * 6))
        PM_MAX_REQUEST=2000
    elif [[ "${CPU_CORES}" -ge '8' && "${CPU_CORES}" -lt '16' && "${RAM_TOTAL}" -gt '3145728' && "${RAM_TOTAL}" -le '4194304' ]]; then
        PM_MAX_CHILDREN=$((CPU_CORES * 6))
        PM_START_SERVERS=$((CPU_CORES * 4))
        PM_MIN_SPARE_SERVER=$((CPU_CORES * 2))
        PM_MAX_SPARE_SERVER=$((CPU_CORES * 6))
        PM_MAX_REQUEST=2000
    elif [[ "${CPU_CORES}" -ge '8' && "${CPU_CORES}" -lt '12' && "${RAM_TOTAL}" -gt '4194304' ]]; then
        PM_MAX_CHILDREN=$((CPU_CORES * 6))
        PM_START_SERVERS=$((CPU_CORES * 4))
        PM_MIN_SPARE_SERVER=$((CPU_CORES * 2))
        PM_MAX_SPARE_SERVER=$((CPU_CORES * 6))
        PM_MAX_REQUEST=2000
    elif [[ "${CPU_CORES}" -ge '13' && "${CPU_CORES}" -lt '16' && "${RAM_TOTAL}" -gt '4194304' ]]; then
        PM_MAX_CHILDREN=$((CPU_CORES * 6))
        PM_START_SERVERS=$((CPU_CORES * 4))
        PM_MIN_SPARE_SERVER=$((CPU_CORES * 2))
        PM_MAX_SPARE_SERVER=$((CPU_CORES * 6))
        PM_MAX_REQUEST=2000
    elif [[ "${CPU_CORES}" -ge '17' && "${RAM_TOTAL}" -gt '4194304' ]]; then
        PM_MAX_CHILDREN=$((CPU_CORES * 5))
        PM_START_SERVERS=$((CPU_CORES * 4))
        PM_MIN_SPARE_SERVER=$((CPU_CORES * 2))
        PM_MAX_SPARE_SERVER=$((CPU_CORES * 5))
        PM_MAX_REQUEST=2000
    else
        PM_MAX_CHILDREN=$(echo "scale=0;${RAM_MB}*0.4/30" | bc)
        PM_START_SERVERS=$((CPU_CORES * 4))
        PM_MIN_SPARE_SERVER=$((CPU_CORES * 2))
        PM_MAX_SPARE_SERVER=$((CPU_CORES * 4))
        PM_MAX_REQUEST=500
    fi
}

memory_calculation(){
    if [[ "${PHP_MEM}" -le '262144' ]]; then
        OPCACHE_MEM='32'
        OPCACHE_JIT_BUFFER='32'
        OPCACHE_STRINGS_BUFFER='8'
        MAX_MEMORY='48'
        PHP_REAL_PATH_LIMIT='512k'
        PHP_REAL_PATH_TTL='14400'
        MAX_INPUT_VARS="6000"
    elif [[ "${PHP_MEM}" -gt '262144' && "${PHP_MEM}" -le '393216' ]]; then
        OPCACHE_MEM='80'
        OPCACHE_JIT_BUFFER='32'
        OPCACHE_STRINGS_BUFFER='8'
        MAX_MEMORY='96'
        PHP_REAL_PATH_LIMIT='640k'
        PHP_REAL_PATH_TTL='21600'
        MAX_INPUT_VARS="6000"
    elif [[ "${PHP_MEM}" -gt '393216' && "${PHP_MEM}" -le '400000' ]]; then
        OPCACHE_MEM='112'
        OPCACHE_JIT_BUFFER='32'
        OPCACHE_STRINGS_BUFFER='8'
        MAX_MEMORY='128'
        PHP_REAL_PATH_LIMIT='768k'
        PHP_REAL_PATH_TTL='21600'
        MAX_INPUT_VARS="6000"
    elif [[ "${PHP_MEM}" -gt '400000' && "${PHP_MEM}" -le '1049576' ]]; then
        OPCACHE_MEM='144'
        OPCACHE_JIT_BUFFER='32'
        OPCACHE_STRINGS_BUFFER='8'
        MAX_MEMORY='160'
        PHP_REAL_PATH_LIMIT='768k'
        PHP_REAL_PATH_TTL='28800'
        MAX_INPUT_VARS="6000"
    elif [[ "${PHP_MEM}" -gt '1049576' && "${PHP_MEM}" -le '2097152' ]]; then
        OPCACHE_MEM='160'
        OPCACHE_JIT_BUFFER='64'
        OPCACHE_STRINGS_BUFFER='16'
        MAX_MEMORY='320'
        PHP_REAL_PATH_LIMIT='1536k'
        PHP_REAL_PATH_TTL='28800'
        MAX_INPUT_VARS="6000"
    elif [[ "${PHP_MEM}" -gt '2097152' && "${PHP_MEM}" -le '3145728' ]]; then
        OPCACHE_MEM='192'
        OPCACHE_JIT_BUFFER='64'
        OPCACHE_STRINGS_BUFFER='16'
        MAX_MEMORY='384'
        PHP_REAL_PATH_LIMIT='2048k'
        PHP_REAL_PATH_TTL='43200'
        MAX_INPUT_VARS="6000"
    elif [[ "${PHP_MEM}" -gt '3145728' && "${PHP_MEM}" -le '4194304' ]]; then
        OPCACHE_MEM='224'
        OPCACHE_JIT_BUFFER='64'
        OPCACHE_STRINGS_BUFFER='16'
        MAX_MEMORY='512'
        PHP_REAL_PATH_LIMIT='3072k'
        PHP_REAL_PATH_TTL='43200'
        MAX_INPUT_VARS="6000"
    elif [[ "${PHP_MEM}" -gt '4194304' && "${PHP_MEM}" -le '8180000' ]]; then
        OPCACHE_MEM='288'
        OPCACHE_JIT_BUFFER='128'
        OPCACHE_STRINGS_BUFFER='24'
        MAX_MEMORY='640'
        PHP_REAL_PATH_LIMIT='4096k'
        PHP_REAL_PATH_TTL='43200'
        MAX_INPUT_VARS="10000"
    elif [[ "${PHP_MEM}" -gt '8180000' && "${PHP_MEM}" -le '16360000' ]]; then
        OPCACHE_MEM='320'
        OPCACHE_JIT_BUFFER='256'
        OPCACHE_STRINGS_BUFFER='32'
        MAX_MEMORY='800'
        PHP_REAL_PATH_LIMIT='4096k'
        PHP_REAL_PATH_TTL='43200'
        MAX_INPUT_VARS="10000"
    elif [[ "${PHP_MEM}" -gt '16360000' && "${PHP_MEM}" -le '32400000' ]]; then
        OPCACHE_MEM='480'
        OPCACHE_JIT_BUFFER='256'
        OPCACHE_STRINGS_BUFFER='32'
        MAX_MEMORY='1024'
        PHP_REAL_PATH_LIMIT='4096k'
        PHP_REAL_PATH_TTL='43200'
        MAX_INPUT_VARS="10000"
    elif [[ "${PHP_MEM}" -gt '32400000' && "${PHP_MEM}" -le '64800000' ]]; then
        OPCACHE_MEM='600'
        OPCACHE_JIT_BUFFER='256'
        OPCACHE_STRINGS_BUFFER='32'
        MAX_MEMORY='1280'
        PHP_REAL_PATH_LIMIT='4096k'
        PHP_REAL_PATH_TTL='43200'
        MAX_INPUT_VARS="10000"
    elif [[ "${PHP_MEM}" -gt '64800000' ]]; then
        OPCACHE_MEM='800'
        OPCACHE_JIT_BUFFER='256'
        OPCACHE_STRINGS_BUFFER='32'
        MAX_MEMORY='2048'
        PHP_REAL_PATH_LIMIT='8192k'
        PHP_REAL_PATH_TTL='86400'
        MAX_INPUT_VARS="10000"
    fi
}

php_parameter
memory_calculation
