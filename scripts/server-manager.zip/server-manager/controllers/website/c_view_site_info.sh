#!/bin/bash

##############################################################################################################
#                             Auto Install & Optimize LEMP Stack on Ubuntu                                   #
#                                                                                                            #
#                                    Author: Sanvv - MCN Technical                                        #
#                                        Website: https://mcnvps.net                                          #
#                                                                                                            #
#                                  Please do not remove copyright. Thank!                                    #
#  Copying or using this content for any commercial purpose is strictly prohibited under all circumstances!  #
##############################################################################################################

view_website_details() {
    local domain
    run_prompt_or_exit prompt_select_website domain "website_menu"

    local db_user
    local db_pass
    local db_name
    local base_dir
    local website_source
    local php_version
    local php_post_max_size
    local php_upload_max_filesize
    local php_memory_limit
    local sftp_user
    local sftp_pass

    # shellcheck disable=SC1090
    source "${WEB_DATA_DIR}/${domain}/.settings.conf" || {
        msg "$ICON_EXIT Khong the load file cau hinh: ${domain}"
        exit 1
    }

    printf "\n"
    echo "${GREEN}Duoi day la thong tin Website${NC} ${RED}$domain${NC}"
    echo "${GREEN}-----------------------------------${NC}"
    echo "${GREEN}MySQL User               :${NC} ${RED}$db_user${NC}"
    echo "${GREEN}MySQL Password           :${NC} ${RED}$db_pass${NC}"
    echo "${GREEN}Database name            :${NC} ${RED}$db_name${NC}"
    echo ""
    echo "${GREEN}Web basedir              :${NC} ${RED}$base_dir${NC}"
    echo "${GREEN}Website source           :${NC} ${RED}$website_source${NC}"
    echo ""
    echo "${GREEN}PHP Version              :${NC} ${RED}$php_version${NC}"
    echo "${GREEN}PHP post max size        :${NC} ${RED}$php_post_max_size M${NC}"
    echo "${GREEN}PHP upload max file size :${NC} ${RED}$php_upload_max_filesize M${NC}"
    echo "${GREEN}PHP memory limit         :${NC} ${RED}$php_memory_limit M${NC}"

    if [[ -n "$sftp_user" ]]; then
        echo ""
        echo "${GREEN}--- SFTP ---${NC}"
        echo "${GREEN}SFTP Host                :${NC} ${RED}${IP_ADDRESS}${NC}"
        echo "${GREEN}SFTP Port                :${NC} ${RED}$(detect_ssh_port)${NC}"
        echo "${GREEN}SFTP User                :${NC} ${RED}$sftp_user${NC}"
        echo "${GREEN}SFTP Password            :${NC} ${RED}$sftp_pass${NC}"
        echo "${GREEN}SFTP Directory           :${NC} ${RED}/${domain}/public_html${NC}"
    fi

    local wp_config_found=false
    [[ -f "${base_dir}/public_html/wp-config.php" ]] && wp_config_found=true
    [[ -f "${base_dir}/wp-config.php" ]] && wp_config_found=true

    if [[ "$website_source" == "wordpress" && "$wp_config_found" == true ]]; then
        echo ""
        echo "${GREEN}--- WordPress Admin ---${NC}"
        local wp_token wp_admin_login wp_site_url wp_login_file wp_login_url
        local was_locked=false
        if lsattr "${base_dir}/public_html/wp-load.php" 2>/dev/null | awk '{print $1}' | grep -q 'i'; then
            was_locked=true
            chattr -i "${base_dir}/public_html" 2>/dev/null
        fi

        # Xoa file login cu truoc khi tao moi
        find "${base_dir}/public_html" -maxdepth 1 -name "mcn_login_*.php" -exec chattr -i {} \; 2>/dev/null
        find "${base_dir}/public_html" -maxdepth 1 -name "mcn_login_*.php" -type f -delete 2>/dev/null

        wp_token=$(openssl rand -hex 16)
        wp_admin_login=$(wp --allow-root --path="${base_dir}/public_html" user list --role=administrator --fields=user_login --format=csv 2>/dev/null | tail -n +2 | head -1)
        wp_site_url=$(wp --allow-root --path="${base_dir}/public_html" option get siteurl 2>/dev/null)
        wp_login_file="${base_dir}/public_html/mcn_login_${wp_token}.php"

        cat > "$wp_login_file" << PHPEOF
<?php
// Auto-expire after 5 minutes
if (filemtime(__FILE__) < time() - 300) { unlink(__FILE__); die('Link het han.'); }
require_once dirname(__FILE__).'/wp-load.php';
\$users = get_users(['role'=>'administrator','number'=>1]);
if (!empty(\$users)) {
    wp_set_auth_cookie(\$users[0]->ID, true);
}
unlink(__FILE__);
wp_redirect(admin_url());
exit;
PHPEOF

        chown "${owner}:${owner}" "$wp_login_file" 2>/dev/null
        chmod 644 "$wp_login_file"

        if [[ "$was_locked" == true ]]; then
            chattr +i "${base_dir}/public_html" 2>/dev/null
        fi

        wp_login_url="${wp_site_url}/mcn_login_${wp_token}.php"

        if [[ -n "$wp_admin_login" ]]; then
            echo "${GREEN}WP Admin User            :${NC} ${RED}${wp_admin_login}${NC}"
        fi
        echo "${GREEN}Dang nhap nhanh (1 lan)  :${NC} ${RED}${wp_login_url}${NC}"
    fi

    press_enter_to_continue; return 0
}
